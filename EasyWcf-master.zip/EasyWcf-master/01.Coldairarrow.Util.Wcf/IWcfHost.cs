﻿namespace Coldairarrow.Util.Wcf
{
    public interface IWcfHost
    {
        void StartHost();
    }
}