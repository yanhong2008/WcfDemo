# EasyWcf
A very easy way to use Wcf<br />
How to use it is here:http://www.cnblogs.com/coldairarrow/p/7811530.html

