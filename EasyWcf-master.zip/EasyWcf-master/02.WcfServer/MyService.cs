﻿namespace WcfServer
{
    public class MyService : IMyService
    {
        public string Hello()
        {
            return "Hello World!";
        }
    }
}
